# @foxy.io/design-system

Foxy's design system: [Base UI](https://base-ui.com) primitives wrapped in
[styled-components](https://styled-components.com), themed with the Foxy brand tokens.

Every component is a styled Base UI part, so accessibility and keyboard behaviour come from Base UI
and the look comes from a theme object you control.

## Install

> Not published yet — the package version is `0.0.0`. The command below is the install path once the
> first release lands.

```bash
npm install @foxy.io/design-system
```

Peer dependencies you install yourself:

```bash
npm install react react-dom styled-components
```

React and React DOM are declared as peer dependencies (`^19.2.7`) — you must install them.
`styled-components` (`^6`) is a direct dependency of this package, so it arrives on its own, but
your app imports `ThemeProvider` from it directly. Declare it in your own `package.json` too, and
keep it on a single version — two copies of styled-components means two style sheets, and the theme
reaches only one of them.

## Minimum setup

Two things are required at the root of your app: the brand fonts and a `ThemeProvider`.

```tsx
import { FontFaces, Button } from "@foxy.io/design-system";
import { defaultTheme } from "@foxy.io/design-system/theme";
import { ThemeProvider } from "styled-components";

export function App() {
  return (
    <ThemeProvider theme={{ tokens: defaultTheme }}>
      <FontFaces />
      <Button>Add to cart</Button>
    </ThemeProvider>
  );
}
```

`FontFaces` renders `<link>` tags that load the brand typefaces from Google Fonts; every font
token names Albert Sans. The design system ships no other global CSS, so without `FontFaces`
components render in a fallback face.

The theme passed to `ThemeProvider` is **not** `defaultTheme` itself. It is an object with
`defaultTheme` under a `tokens` key. Everything else on that object is per-component overrides —
see [Theming](#theming).

## Imports

Two import styles, both published, both giving you the same components:

```tsx
// Root barrel — every component.
import { Button, Field, Select } from "@foxy.io/design-system";

// Subpath — one component each.
import { Button } from "@foxy.io/design-system/button";
import { Field } from "@foxy.io/design-system/field";
```

Use the root barrel by default. Reach for a subpath when your bundler cannot tree-shake the barrel,
or when you want an import to name exactly what it pulls in. Both resolve to separate built files,
so a subpath import never pulls in the other 30-odd components.

Two subpaths are not components and are worth knowing by name:

| Subpath                                | Exports                                            | Also in the root barrel?   |
| -------------------------------------- | -------------------------------------------------- | -------------------------- |
| `@foxy.io/design-system/theme`         | `defaultTheme`, `DesignSystemTheme`, `ThemeTokens` | No — theme is subpath-only |
| `@foxy.io/design-system/global-styles` | `FontFaces`                                        | Yes                        |

## TypeScript

Nothing to set up. The `styled-components` `DefaultTheme` augmentation ships with the package, and
importing anything from `@foxy.io/design-system` or `@foxy.io/design-system/theme` applies it to your
whole project. A module augmentation is program-wide, so one import in one file is enough — you do
not need it in every file that reads the theme.

What that gives you:

- `props.theme.tokens` is typed inside your own styled components. Token names are checked
  (`theme.tokens.color.primaryy` is an error, `theme.tokens.color.primary` is not) and token values
  stay free, so you can change them.
- The object you pass to `ThemeProvider` is checked key by key. A missing `tokens`, a misspelled
  component name, a misspelled property, an unsupported state, and a part name the component does
  not have are all type errors.

`ThemeTokens` is exported from both entries, for when you want to name the token half of the theme
yourself.

One gap: a file that only ever imports a component subpath (`@foxy.io/design-system/button`) and
never the root barrel or `/theme` does not pull the augmentation in. Add it once, anywhere in the
project:

```ts
import type {} from "@foxy.io/design-system";
```

## Theming

### Tokens

`theme.tokens` is the shared vocabulary every component reads. Change a token and every component
that uses it follows. The groups are `color`, `background`, `border`, `borderRadius`, `outline`,
`font`, `letterSpacing`, `textTransform`, `space`, `size`, `easing`, `duration`, and `zIndex`.

```tsx
import { defaultTheme } from "@foxy.io/design-system/theme";

const brandTheme = {
  tokens: {
    ...defaultTheme,
    color: { ...defaultTheme.color, primary: "#0B7285" },
    borderRadius: { ...defaultTheme.borderRadius, sm: "0" },
  },
};
```

Spread `defaultTheme` group by group like this. `tokens` is read whole — a partial object leaves
components reading `undefined` for the tokens you left out.

### Per-component overrides

Anything you cannot express in tokens goes on the theme next to `tokens`, keyed by component name.
This is the least guessable part of the API, so here is the whole contract.

A flat override targets a component with no inner parts:

```tsx
<ThemeProvider theme={{ tokens: defaultTheme, Button: { "border-radius": "0" } }}>
```

A nested key targets one part of a compound component:

```tsx
<ThemeProvider
  theme={{
    tokens: defaultTheme,
    Switch: { Root: { Thumb: { background: "#0B7285" } } },
  }}
>
```

A state key wraps the properties inside it in a state selector:

```tsx
<ThemeProvider
  theme={{
    tokens: defaultTheme,
    Button: { background: "#0B7285", hover: { background: "#095C6B" } },
  }}
>
```

Four rules govern what is accepted:

1. **Properties.** Only these 16 CSS properties are emitted: `color`, `background`, `font`,
   `text-transform`, `letter-spacing`, `padding`, `height`, `width`, `border`, `border-radius`,
   `transform`, `opacity`, `outline`, `filter`, `backdrop-filter`, `transition`. They are CSS names
   in kebab-case, not camelCase React style props.
2. **States.** Only these six: `hover`, `active`, `disabled`, `focused`, `invalid`, `touched`.
   `hover` and `active` compile to `&:hover` and `&:active`; the other four compile to
   `&[data-disabled]`, `&[data-focused]`, `&[data-invalid]`, `&[data-touched]`. States nest inside
   each other and inside part keys.
3. **Parts.** A nested part key only works where the component wires up a part map. These do:
   `Alert.Root`, `Calendar.Root`, `Card.Root`, `Checkbox.Root`, `Collapsible.Root`, `Command.Root`,
   `Field.Root`, `Field.Set`, `InputGroup.Root`, `Item.Root`, `Progress.Root`, `Radio.Root`,
   `ScrollArea.Root`, `SummaryTable.Root`, `Switch.Root`. Components whose parts are addressed
   directly — `Dialog.Popup`, `Tooltip.Popup`, `Popover.Popup`, `NavigationMenu.Trigger` and the
   like — take a flat override on that part instead.
4. **Unknown keys are dropped silently at runtime.** A misspelled property, an unsupported state,
   or a part name the component does not know produces no CSS and no warning. In TypeScript the
   theme augmentation catches all three before you run; in plain JavaScript, if an override does
   nothing, check it against the three lists above first.

### Motion

A `transition` override automatically gets a `@media (prefers-reduced-motion: reduce)` guard
alongside it, so a consumer theme cannot bring back motion for someone who asked not to see it. You
do not need to write the guard yourself.

## Storybook

Every component has stories, and `Overview → Getting Started` carries this same guide with live,
themed examples.

```bash
npm run storybook
```

The published Storybook is the reference for what each component looks like and which props it
takes.

## Development

- Install dependencies:

```bash
vp install
```

- Format, lint and type check:

```bash
vp check
```

- Run the tests (Storybook play functions, in a real browser):

```bash
vp test
```

- Build the library:

```bash
vp pack
```

## License

MIT
